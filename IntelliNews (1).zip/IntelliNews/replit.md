# IntelliNews — Cloud-Based Credibility Engine

## Overview
A Streamlit application that scores and ranks news articles by credibility using
two core data structures: a Hash Map for O(1) source verification and a Priority
Queue (min-heap) for O(log N) ranked feed management.

## Architecture

### Trust Database — O(1) Hash Map
- Python `dict` mapping 10 real-world domains to credibility scores (0.0 – 1.0)
- Unknown domains default to 0.40
- Instant lookup regardless of database size

### Ranking Engine — O(log N) Priority Queue
- `heapq` binary min-heap with **negated** scores (highest credibility at top)
- Each insert/pop touches only log₂(N) nodes
- Stored in `st.session_state` for persistence across rerenders

### Validation Logic
- Extracts bare domain from any URL (strips protocol, www, path)
- Penalises ALL-CAPS words (≥4 chars): −0.05 each, max −0.30
- Penalises extra `!` beyond the first: −0.05 each, max −0.20

## File Structure
```
app.py            — Main Streamlit application (all logic + UI)
requirements.txt  — streamlit, pandas
.streamlit/
  config.toml     — Disables usage stats prompt, sets port 5000
main.py           — Placeholder / entry-point comment
```

## Running the App
```
streamlit run app.py --server.port 5000 --server.address 0.0.0.0
```
Workflow "Start application" is configured for this command.

## UI Sections
1. **Sidebar** — DSA explainer (expandable), known-domains table
2. **Submit a Story** — Headline + Source URL inputs, Process button
3. **Live Score Preview** — Real-time score while typing
4. **Live Ranked Feed** — Color-coded cards (Green ≥0.80, Yellow ≥0.55, Red <0.55)
