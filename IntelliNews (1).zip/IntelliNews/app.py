import streamlit as st
import heapq
import pandas as pd
import re
import time

st.set_page_config(
    page_title="IntelliNews",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── O(1) TRUST DATABASE — Categorised Hash Map (Python dict) ────────────────
#   Structure: domain → {"score": float, "category": str}
TRUST_DB = {
    # ── National / Indian News ────────────────────────────────────────────────
    "thehindu.com":               {"score": 0.92, "category": "National"},
    "timesofindia.indiatimes.com":{"score": 0.91, "category": "National"},
    "ndtv.com":                   {"score": 0.90, "category": "National"},
    # ── Education ─────────────────────────────────────────────────────────────
    "ugc.ac.in":                  {"score": 1.00, "category": "Education"},
    "cbse.gov.in":                {"score": 1.00, "category": "Education"},
    # ── Politics ──────────────────────────────────────────────────────────────
    "pib.gov.in":                 {"score": 0.95, "category": "Politics"},
    "theprint.in":                {"score": 0.90, "category": "Politics"},
    # ── Sports ────────────────────────────────────────────────────────────────
    "espn.com":                   {"score": 0.85, "category": "Sports"},
    "sportskeeda.com":            {"score": 0.85, "category": "Sports"},
    # ── Entertainment / Cinema ────────────────────────────────────────────────
    "variety.com":                {"score": 0.80, "category": "Entertainment"},
    "bollywoodhungama.com":       {"score": 0.80, "category": "Entertainment"},
    # ── International ─────────────────────────────────────────────────────────
    "reuters.com":                {"score": 0.97, "category": "International"},
    "apnews.com":                 {"score": 0.96, "category": "International"},
    "bbc.com":                    {"score": 0.94, "category": "International"},
    "aljazeera.com":              {"score": 0.82, "category": "International"},
    # ── Low Credibility ───────────────────────────────────────────────────────
    "infowars.com":               {"score": 0.12, "category": "Unverified"},
}

# Aliases that trigger the WhatsApp / forwarded message penalty
FORWARDED_ALIASES = {
    "whatsapp", "whatsapp-forward", "whatsapp-msg",
    "forwarded", "forward", "telegram-forward",
}

CATEGORY_COLORS = {
    "National":      "#1a4fba",
    "Education":     "#6a0dad",
    "Politics":      "#b8860b",
    "Sports":        "#0a7a3a",
    "Entertainment": "#c0006a",
    "International": "#0a5a7a",
    "Unverified":    "#8a0000",
    "Social":        "#8a4a00",
    "Unknown":       "#555555",
}


# ─── VALIDATION LOGIC ─────────────────────────────────────────────────────────
def extract_domain(url: str) -> str:
    """Strip protocol and path, return bare domain."""
    url = url.lower().strip()
    url = re.sub(r"^https?://", "", url)
    url = re.sub(r"^www\.", "", url)
    domain = url.split("/")[0]
    return domain


def calculate_score(headline: str, source_url: str) -> tuple[float, float, str, str]:
    """
    Returns (final_score, base_trust, domain, category).
    O(1) hash-map lookup.  Penalties for ALL-CAPS and excessive '!'.
    WhatsApp / forwarded sources receive a hard floor of 0.20.
    """
    domain = extract_domain(source_url)

    # WhatsApp / forwarded message rule
    if domain in FORWARDED_ALIASES:
        base_trust = 0.20
        category = "Social"
    else:
        record = TRUST_DB.get(domain)
        if record:
            base_trust = record["score"]
            category = record["category"]
        else:
            base_trust = 0.40
            category = "Unknown"

    # Penalty: each ALL-CAPS word (≥4 chars) costs 0.05, max 0.30
    caps_words = re.findall(r'\b[A-Z]{4,}\b', headline)
    caps_penalty = min(len(caps_words) * 0.05, 0.30)

    # Penalty: each extra '!' beyond first costs 0.05, max 0.20
    exclamation_count = headline.count("!")
    exclamation_penalty = min(max(exclamation_count - 1, 0) * 0.05, 0.20)

    final_score = round(max(base_trust - caps_penalty - exclamation_penalty, 0.0), 4)
    return final_score, base_trust, domain, category


# ─── MOCK DATA — 18 articles across all categories ───────────────────────────
MOCK_ARTICLES = [
    # ── Education ─────────────────────────────────────────────────────────────
    {
        "headline": "CBSE Board Exam Dates Announced for 2026",
        "url": "https://cbse.gov.in/newsite/attach/2025/board-exam-dates-2026.pdf",
        "timestamp": "07:30:00",
    },
    {
        "headline": "UGC Releases New Guidelines for Undergraduate Admissions 2025",
        "url": "https://ugc.ac.in/pdfnews/ugc-ug-admission-guidelines-2025.pdf",
        "timestamp": "07:55:10",
    },
    # ── Politics ──────────────────────────────────────────────────────────────
    {
        "headline": "Government Announces New Green Energy Subsidy for Rural Households",
        "url": "https://pib.gov.in/PressReleasePage.aspx?PRID=2085001",
        "timestamp": "08:10:45",
    },
    {
        "headline": "Cabinet Approves Rs 10,000 Crore Infrastructure Fund for Northeast India",
        "url": "https://pib.gov.in/PressReleasePage.aspx?PRID=2086234",
        "timestamp": "08:40:20",
    },
    {
        "headline": "Parliament Passes Digital Privacy Bill After Three-Day Debate",
        "url": "https://theprint.in/politics/parliament-digital-privacy-bill-passed/2025",
        "timestamp": "09:05:33",
    },
    # ── National ──────────────────────────────────────────────────────────────
    {
        "headline": "New National Education Policy Phase 2 Updates Released by Ministry",
        "url": "https://thehindu.com/education/national-education-policy-phase-2-updates/article68910000.ece",
        "timestamp": "09:30:00",
    },
    {
        "headline": "India's GDP Growth Forecast Revised to 7.2% for 2025-26",
        "url": "https://timesofindia.indiatimes.com/business/india-business/gdp-growth-forecast-revised/articleshow/118900001.cms",
        "timestamp": "09:55:15",
    },
    {
        "headline": "Monsoon to Arrive Early This Year, IMD Issues Forecast",
        "url": "https://ndtv.com/india-news/monsoon-early-arrival-imd-forecast-2025-7120001",
        "timestamp": "10:20:00",
    },
    # ── Sports ────────────────────────────────────────────────────────────────
    {
        "headline": "National Cricket Captain Retires from International Cricket After Historic Career",
        "url": "https://espn.com/cricket/story/_/id/39000001/india-captain-rohit-sharma-retirement-announcement",
        "timestamp": "10:45:22",
    },
    {
        "headline": "India Wins Gold in Badminton at Asian Games 2025",
        "url": "https://sportskeeda.com/badminton/india-wins-gold-asian-games-2025",
        "timestamp": "11:10:08",
    },
    # ── International ─────────────────────────────────────────────────────────
    {
        "headline": "G20 Leaders Agree on Framework to Combat Climate Change",
        "url": "https://reuters.com/world/g20-climate-change-framework-agreement-2025-04-10",
        "timestamp": "11:30:00",
    },
    {
        "headline": "Global Inflation Eases as Central Banks Signal Rate Cuts",
        "url": "https://apnews.com/article/global-inflation-central-banks-rate-cuts-2025",
        "timestamp": "11:48:17",
    },
    {
        "headline": "WHO Declares End to Mpox Public Health Emergency",
        "url": "https://bbc.com/news/health/who-mpox-emergency-end-2025",
        "timestamp": "12:05:50",
    },
    # ── Entertainment ─────────────────────────────────────────────────────────
    {
        "headline": "LEAKED: New Blockbuster Trailer Reveals Major Spoiler!!!",
        "url": "https://bollywoodhungama.com/movies/new-blockbuster-trailer-leaked-spoiler",
        "timestamp": "12:30:44",
    },
    {
        "headline": "Cannes 2025 Lineup Announced — Indian Film Gets Opening Slot",
        "url": "https://variety.com/2025/film/news/cannes-2025-lineup-official-selection-india",
        "timestamp": "12:55:00",
    },
    # ── Social / WhatsApp Forward ──────────────────────────────────────────────
    {
        "headline": "URGENT: Local Water Supply to be Cut for 48 Hours — Share Now!!!",
        "url": "whatsapp-forward",
        "timestamp": "13:10:12",
    },
    {
        "headline": "FREE Recharge for All BSNL Users This Week — Forward to Claim!!!",
        "url": "whatsapp-forward",
        "timestamp": "13:22:05",
    },
    # ── Unverified / Viral / Low Credibility ──────────────────────────────────
    {
        "headline": "Viral Video of Miracle Cure is 100% REAL Doctors CONFIRM!!!",
        "url": "https://viralhealth99.net/miracle-cure-video-doctors-confirm",
        "timestamp": "13:45:30",
    },
]


def seed_mock_data():
    """Score each mock article and push into the priority queue."""
    for article in MOCK_ARTICLES:
        score, base, domain, category = calculate_score(article["headline"], article["url"])
        entry = {
            "headline": article["headline"],
            "url": article["url"],
            "domain": domain,
            "base_trust": base,
            "final_score": score,
            "timestamp": article["timestamp"],
            "known": domain in TRUST_DB or domain in FORWARDED_ALIASES,
            "category": category,
            "mock": True,
        }
        heapq.heappush(
            st.session_state.feed_heap,
            (-score, st.session_state.feed_counter, entry)
        )
        st.session_state.feed_counter += 1


# ─── SESSION STATE INIT ───────────────────────────────────────────────────────
if "feed_heap" not in st.session_state:
    st.session_state.feed_heap = []
    st.session_state.feed_counter = 0
    seed_mock_data()
elif "feed_counter" not in st.session_state:
    st.session_state.feed_counter = 0


# ─── SIDEBAR — DSA EXPLAINER ──────────────────────────────────────────────────
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/brain.png", width=64)
    st.title("IntelliNews")
    st.caption("Cloud-Based Credibility Engine")
    st.divider()

    st.subheader("⚙️ DSA Under the Hood")

    with st.expander("Hash Map  —  O(1) Lookup", expanded=True):
        st.markdown(
            """
**Data Structure:** Python `dict`

The **Trust Database** maps each domain to a credibility
score **and** category — both retrieved in O(1) time.

```
TRUST_DB["cbse.gov.in"]
  → {"score": 1.00, "category": "Education"}

TRUST_DB["infowars.com"]
  → {"score": 0.12, "category": "Unverified"}
```

No matter how large the database grows, every lookup
costs **constant time**.
"""
        )

    with st.expander("Priority Queue  —  O(log N) Insert/Pop", expanded=True):
        st.markdown(
            """
**Data Structure:** Python `heapq` (binary min-heap)

Stories are stored with **negated** scores so the highest
credibility always sits at the top of the heap.

```
heapq.heappush(heap, (-score, counter, item))  # O(log N)
heapq.heappop(heap)                            # O(log N)
```

Each insert or removal touches only **log₂(N)** nodes.
"""
        )

    with st.expander("Validation Penalties", expanded=False):
        st.markdown(
            """
**Penalties that reduce the headline trust score:**

| Signal | Penalty |
|---|---|
| ALL-CAPS word (≥4 chars) | −0.05 each (max −0.30) |
| Extra `!` beyond first | −0.05 each (max −0.20) |
| WhatsApp / Forwarded source | Hard floor: 0.20 base |

Unknown domains default to **0.40**.
"""
        )

    st.divider()
    st.subheader("📋 Trust Database")
    df_db = pd.DataFrame(
        [
            (k, v["category"], v["score"])
            for k, v in sorted(TRUST_DB.items(), key=lambda x: -x[1]["score"])
        ],
        columns=["Domain", "Category", "Score"],
    )
    st.dataframe(df_db, use_container_width=True, hide_index=True)


# ─── MAIN PANEL ───────────────────────────────────────────────────────────────
st.title("🧠 IntelliNews — Credibility Engine")
st.markdown(
    "Submit a headline and source URL. The engine scores it using "
    "**O(1) hash-map lookup** and queues it in a **O(log N) priority heap**."
)
st.divider()

# ── Input Section ──────────────────────────────────────────────────────────────
col_left, col_right = st.columns([2, 1], gap="large")

with col_left:
    st.subheader("📝 Submit a Story")
    headline = st.text_input(
        "Headline",
        placeholder="Enter the news headline here…",
        key="headline_input",
    )
    source_url = st.text_input(
        "Source URL",
        placeholder="e.g. https://thehindu.com/article  or  whatsapp-forward",
        key="source_url_input",
    )
    process_clicked = st.button("⚡ Process & Queue", type="primary", use_container_width=True)

with col_right:
    st.subheader("📊 Live Score Preview")
    if headline and source_url:
        score, base, domain, category = calculate_score(headline, source_url)
        known = domain in TRUST_DB or domain in FORWARDED_ALIASES
        cat_color = CATEGORY_COLORS.get(category, "#555")

        st.metric("Credibility Score", f"{score:.2f}")
        st.caption(f"Domain: `{domain}`")
        st.markdown(
            f'<span style="background:{cat_color}; color:#fff; padding:2px 10px; '
            f'border-radius:12px; font-size:0.8em; font-weight:600;">{category}</span>',
            unsafe_allow_html=True,
        )
        st.write("")
        if domain in FORWARDED_ALIASES:
            st.error("📲 WhatsApp / Forwarded — base score capped at 0.20")
        elif known:
            st.success("✅ Verified source in Trust DB")
        else:
            st.warning("⚠️ Unknown source — default score applied")
    else:
        st.info("Fill in the headline and URL to see a live preview.")


# ── Process Button Logic ───────────────────────────────────────────────────────
if process_clicked:
    if not headline.strip():
        st.error("Please enter a headline.")
    elif not source_url.strip():
        st.error("Please enter a source URL.")
    else:
        score, base, domain, category = calculate_score(headline, source_url)
        entry = {
            "headline": headline.strip(),
            "url": source_url.strip(),
            "domain": domain,
            "base_trust": base,
            "final_score": score,
            "timestamp": time.strftime("%H:%M:%S"),
            "known": domain in TRUST_DB or domain in FORWARDED_ALIASES,
            "category": category,
        }
        heapq.heappush(
            st.session_state.feed_heap,
            (-score, st.session_state.feed_counter, entry)
        )
        st.session_state.feed_counter += 1
        st.success(f"Story queued!  Category: **{category}**  |  Credibility Score: **{score:.2f}**")
        st.rerun()


st.divider()

# ── Live Ranked Feed ───────────────────────────────────────────────────────────
st.subheader("📡 Live Ranked Feed")
st.caption(
    "Sorted highest → lowest credibility by binary heap.  "
    "Colors = trust level.  Tags = article category."
)

if not st.session_state.feed_heap:
    st.info("No stories in the feed yet. Submit one above to get started!")
else:
    sorted_entries = sorted(st.session_state.feed_heap, key=lambda x: x[0])

    for neg_score, _counter, entry in sorted_entries:
        score = -neg_score
        category = entry.get("category", "Unknown")
        cat_color = CATEGORY_COLORS.get(category, "#555555")

        # Trust-level colours
        if score >= 0.80:
            badge = "🟢"
            level = "HIGH"
            card_color = "#1a7a1a"
            card_bg = "#eaffea"
            bar_color = "#2ecc71"
        elif score >= 0.55:
            badge = "🟡"
            level = "MEDIUM"
            card_color = "#7a6800"
            card_bg = "#fffbe6"
            bar_color = "#f1c40f"
        else:
            badge = "🔴"
            level = "LOW"
            card_color = "#7a1a1a"
            card_bg = "#ffeaea"
            bar_color = "#e74c3c"

        sim_html = (
            '<span style="font-size:0.70em; background:#dde8ff; color:#1a3a8a; '
            'border-radius:4px; padding:1px 6px; margin-left:5px; font-weight:600;">SIMULATED</span>'
            if entry.get("mock") else ""
        )

        cat_html = (
            f'<span style="font-size:0.70em; background:{cat_color}; color:#fff; '
            f'border-radius:4px; padding:1px 7px; margin-left:5px; font-weight:700; '
            f'letter-spacing:0.05em;">{category.upper()}</span>'
        )

        # Score bar width as percentage (max score 1.0)
        bar_width = int(score * 100)

        wa_flag = ""
        if entry.get("domain") in FORWARDED_ALIASES:
            wa_flag = '&nbsp;<span style="font-size:0.78em;">📲 WhatsApp Forward</span>'

        verified_html = "&#9989; Verified" if entry['known'] else "&#9888; Unknown"

        # Headline — clickable link for real URLs, plain text for WhatsApp forwards
        is_forwarded = entry.get("domain") in FORWARDED_ALIASES
        if is_forwarded:
            headline_html = (
                f"<span style='font-size:1.05em; font-weight:700; color:{card_color};'>"
                f"{badge} [{level}]&nbsp; {entry['headline']}"
                f"</span>"
            )
            source_link = f"<b>📲 WhatsApp Forward</b> (no URL)"
        else:
            headline_html = (
                f"<a href='{entry['url']}' target='_blank' style='font-size:1.05em; font-weight:700; "
                f"color:{card_color}; text-decoration:none;'>"
                f"{badge} [{level}]&nbsp; {entry['headline']}"
                f"</a>"
            )
            source_link = (
                f"&#128279; <a href='{entry['url']}' target='_blank' "
                f"style='color:#0a5a7a;'>{entry['url']}</a>"
            )

        meta = (
            f"{source_link}"
            f"{wa_flag} &nbsp;&#124;&nbsp; "
            f"Domain: <b>{entry['domain']}</b> &nbsp;&#124;&nbsp; "
            f"Score: <b>{score:.2f}</b> &nbsp;&#124;&nbsp; "
            f"&#128336; {entry['timestamp']} &nbsp;&#124;&nbsp; {verified_html}"
        )
        card_html = (
            f"<div style='background:{card_bg}; border-left:5px solid {card_color}; "
            f"border-radius:6px; padding:10px 16px 8px 16px; margin-bottom:10px;'>"
            f"<div style='margin-bottom:4px;'>"
            f"{headline_html}{cat_html}{sim_html}"
            f"</div>"
            f"<div style='background:#e0e0e0; border-radius:4px; height:6px; margin:6px 0 8px 0;'>"
            f"<div style='background:{bar_color}; width:{bar_width}%; height:6px; border-radius:4px;'></div>"
            f"</div>"
            f"<span style='font-size:0.80em; color:#555; word-break:break-all;'>{meta}</span>"
            f"</div>"
        )
        st.markdown(card_html, unsafe_allow_html=True)

    st.divider()
    if st.button("🗑️ Clear Feed", type="secondary"):
        st.session_state.feed_heap = []
        st.session_state.feed_counter = 0
        st.rerun()
